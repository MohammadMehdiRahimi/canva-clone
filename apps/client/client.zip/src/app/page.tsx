"use client";



import React from "react";
export default function Home() {


  return (
    <>
   Home page
    </>
  );
}
