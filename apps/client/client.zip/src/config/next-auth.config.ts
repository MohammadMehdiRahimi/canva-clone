import NextAuth, { NextAuthOptions } from "next-auth";
import Google from "next-auth/providers/google";

const CLIENT_ID = process.env.GOOGLE_ID;
const CLIENT_SECRET = process.env.GOOGLE_SECRET;
const AUTH_SECRET = process.env.AUTH_SECRET;

if (
  CLIENT_ID === undefined ||
  CLIENT_SECRET === undefined ||
  AUTH_SECRET === undefined
) {
  throw new Error("Missing environment variables for authentication");
}

export  const authOptions: NextAuthOptions = {
  session: {
    strategy: "jwt",
  },
  secret: AUTH_SECRET,
  providers: [
    Google({
      clientId: CLIENT_ID,
      clientSecret: CLIENT_SECRET,
    }),
  ],
  callbacks: {
    async jwt({ token, user }) {
      if (user) {
        token.id = user.id;
      }
      return token;
    },
    async session({ session, token }) {
      if (token.id && session.user) {
        session.user.id = token.id as string;
      }

      return session;
    },
  },
};

export const { auth, handlers, signIn, signOut } = NextAuth(authOptions);
